Configuration Apply
{
    [CmdletBinding()]
    param
    (
        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [String[]] $configurations,

        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [String] $node,

        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [String] $storageAccountName,

        [Parameter(Mandatory)]
        [ValidateNotNullOrEmpty()]
        [String] $token
    )

    Import-DSCResource -ModuleName 'xPSDesiredStateConfiguration'

    foreach ($configuration in $configurations)
    {
        if ($configuration -like "main")
        {
            xRemoteFile "Main configuration file"
            {
                Uri = "https://$storageAccountName.file.core.windows.net/datadog/datadog.yaml$token"
                DestinationPath = "C:\ProgramData\Datadog\datadog.yaml"
            }
        }
        else
        {
            $configuration = (Get-Culture).TextInfo.ToTitleCase($configuration)
            xRemoteFile  "$configuration configuration file"
            {
                Uri = "https://$storageAccountName.file.core.windows.net/datadog/$node/$configuration.d/conf.yaml$token"
                DestinationPath = "C:\ProgramData\Datadog\conf.d\$configuration.d\conf.yaml"
            }

        }
    }
}