﻿###########################################################
#
#  'DscInstall' module
#
###########################################################

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$script:DscServiceName = "GCService"
$script:DscServiceBinaryName = "gc_service.exe"
$script:DisplayName = "Guest Configuration Service" 
$script:Description = "This service monitors desired state of the machine."

$script:ExtServiceName = "ExtensionService"
$script:ExtDisplayName = "Guest Configuration Extension service"
$script:ExtDescription = "The service installs the requested extensions"

$script:DscInstallPath = "$PSScriptRoot\..\..\.."
$script:DscBinariesFolderName = "GC"
$script:UserConfigFolderName = "Configuration"
$script:MigratedDataFolderName = "MigratedData"
$script:PullServiceRegistrationInfoFolderName = "PullServiceRegistrationInfo"
$script:DscBinariesPath = Join-Path $script:DscInstallPath $script:DscBinariesFolderName
$script:MigratedDataPath = Join-Path "$script:DscInstallPath\.." $script:MigratedDataFolderName

<#
    .SYNOPSIS
        Perform Dsc Installation tasks. 
        It Installs Dsc Service and restore dsc state from <DscInstall>\..\MigratedData location.
    
    .Example
        Install-Dsc
#>
Function Install-Dsc {
    [CmdletBinding()]
    Param(
        [Parameter()]
        [ValidateSet("Dsc", "Extension")]
        [string]
        $ServiceType = "Dsc"
    )

    Write-Verbose -Message "In Install-Dsc" 

    if ($ServiceType -eq "Extension")
    {
        $dscConfigPath = Join-Path $script:DscBinariesPath 'dsc.config'
        '{ "ServiceType": "Extension" }' | Out-File $dscConfigPath -Encoding utf8
    }

    # Restore DSC state from specified directory.
    #
    # TODO: Open issue to look if we need to keep previous state during upgrade. For this release we can go with no state migration.
    #Restore-DscState

    New-Item $(Get-GuestConfigDataPath) -Force -ItemType Directory
    Set-GuestConfigDataPathAcl

    # Install Dsc Service and verify it is installed correctly. 
    InstallAndValidate-DscService -ServiceType $ServiceType
}


 <#
    .SYNOPSIS
        Perform tasks those are required to be Run in Enable handler of Dsc Windows Extension.  
        
    .Example
        Enable-Dsc 
#>
Function Enable-Dsc {
    [CmdletBinding()]
    Param(
        [Parameter()]
        [ValidateSet("Dsc", "Extension")]
        [string]
        $ServiceType = "Dsc"
    )
    
    Write-Verbose -Message "In Enable-Dsc"

    # For Full Dsc Since there will be no Enable. We should be able to perform all Enable tasks in Install instead. 
    Start-DscService -ServiceType $ServiceType   
}

<#
    .SYNOPSIS
        Perform Dsc UnInstallation tasks. Currently it just Uninstalls the Dsc Service and removes the configuration folder.
    
    .Example
        Uninstall-Dsc
#>
Function Uninstall-Dsc {
    [CmdletBinding()]
    Param(
        [Parameter()]
        [ValidateSet("Dsc", "Extension")]
        [string]
        $ServiceType = "Dsc"
    )

    Write-Verbose -Message "In Uninstall-Dsc"

    # Unregister DSC Timer Service
    Uninstall-DscService -ServiceType $ServiceType

    $guestConfigDataPath = Get-GuestConfigDataPath
    $configurationPath = Join-Path $guestConfigDataPath 'Configuration'
    Write-Verbose "Removing GC user data from $configurationPath path ..."
    if (Test-Path $configurationPath)
    {
        Remove-Item $configurationPath -Recurse -Force
    }
}

<#
    .SYNOPSIS
        Do any state migration during update here.  

    .Example
        Update-Dsc
#>
Function Update-Dsc {
    [CmdletBinding()]
    Param()
    
    Write-Verbose -Message "In Update-Dsc"
}

<#
    .SYNOPSIS
        Install Dsc Service. By default it calculates the Dsc Service Binary Path based on this Dsc Install Module location. 
    
    .Example
        InstallAndValidate-DscService
#>
Function InstallAndValidate-DscService {
    [CmdletBinding()]
    Param(
        [Parameter()]
        [string]
        $ServiceType = "Dsc"
    )

    Write-Verbose -Message "In Install-Dsc Service"

    if($ServiceType -eq "Dsc" -and (CheckServiceExists($script:DscServiceName)))
    {
        Write-Error "Dsc service already exists, can not install new service"
    }
    elseif ($ServiceType -eq "Extension" -and (CheckServiceExists($script:ExtServiceName)))
    {
        Write-Error "Extension service already exists, can not install new service"
    }
    else
    {
        $serviceBinaryPath = Join-Path $script:DscBinariesPath $DscServiceBinaryName
        Write-Verbose -Message "Dsc Service binary path : $serviceBinaryPath."

        $serviceApplication = Get-Command -Name $serviceBinaryPath -TotalCount 1

        if($serviceApplication.CommandType -ne "Application")
        {
            Write-Error "Service binary type is not as expected" 
        }

        $serviceBinaryPathCommand = $serviceBinaryPath + " -k netsvcs"
        
        if($ServiceType -eq "Dsc")
        {
            New-Service -Name $script:DscServiceName -BinaryPathName $serviceBinaryPathCommand -DisplayName $script:DisplayName -Description $script:Description -StartupType Automatic
            $serviceName = $script:DscServiceName
        }
        elseif ($ServiceType -eq "Extension")
        {
            New-Service -Name $script:ExtServiceName -BinaryPathName $serviceBinaryPathCommand -DisplayName $script:ExtDisplayName -Description $script:ExtDescription -StartupType Automatic
            $serviceName = $script:ExtServiceName
        }
        
        
        # For windows 2008 R2 + sp1 start-process with -Wait parameter does not work. Hence sleep for 10 sec instead.
        $osVersion=[Environment]::OSVersion.Version
        if (($osVersion.Major -eq 6) -and ($osVersion.Minor -eq 1) -and ($osVersion.Build -le 7601))
        {
            # configure recovery of the service during failure.
            $configureProcess = Start-Process sc.exe -ArgumentList "failure $serviceName reset= 30 actions= restart/10000/restart/20000/restart/30000" -PassThru
            Start-Sleep -Seconds 10
        }
        else
        {
            # configure recovery of the service during failure.
            $configureProcess = Start-Process sc.exe -ArgumentList "failure $serviceName reset=30 actions=restart/10000/restart/20000/restart/30000" -PassThru -Wait
        }
        if ($configureProcess.ExitCode -ne 0)
        {
            Write-Warning "configuring service recovery options failed with exit-code:- $($configureProcess.ExitCode)"
        }
        Write-Verbose -Message "Successfully Installed new $serviceName."
    }

    Write-Verbose -Message "Validating $serviceName Properties."
   
    # Validate service Properties as returend by Get-Service.
    $serviceObject = Get-Service -Name $serviceName
    
    
    if($serviceObject.Status -eq 'Stopped')
    {
        Write-Verbose -Message "$serviceName is in Stopped State."
    }
    else
    {
        write-error -Message "$serviceName is in unexpected state: " + $serviceObject.Status;
    }

    if($serviceObject.CanPauseAndContinue -eq $false)
    {
        Write-Verbose -Message "$serviceName has correct CanPauseAndContinue State."
    }
    else
    {
        write-error -Message "$serviceName has unexpected CanPauseAndContinue: " + $serviceObject.CanPauseAndContinue;
    }

    if($serviceObject.CanShutdown -eq $false)
    {
        Write-Verbose -Message "$serviceName has correct CanShutdown State."
    }
    else
    {
        write-error -Message "$serviceName has unexpected CanShutdown: " + $serviceObject.CanShutdown;
    }
   
    if($serviceObject.CanStop -eq $false)
    {
        Write-Verbose -Message "$serviceName has correct CanStop State."
    }
    else
    {
        write-error -Message "$serviceName has unexpected CanStop: " + $serviceObject.CanStop;
    }

    if($serviceObject.ServiceType -eq "Win32OwnProcess")
    {
        Write-Verbose -Message "$serviceName will run as Win32OwnProcess."
    }
    else
    {
        write-error -Message "$serviceName has unexpected ServiceType: " + $serviceObject.ServiceType;
    }


    # For windows 2008 R2 + sp1 Get-Service cmdlet does not populate StartType
    if ($serviceObject.PSObject.Properties['StartType'])
    {
        if($serviceObject.StartType -eq "Automatic")
        {
            Write-Verbose -Message "$serviceName will be started Automatically."
        }
        else
        {
            Write-Error -Message "$serviceName has unexpected StartType: " + $serviceObject.StartType;
        }
    }
    else
    {
        # configure recovery of the service during failure.
        $ServiceStartType = ([string](sc.exe qc $serviceName | Select-String 'START_TYPE')).Split(' ',[System.StringSplitOptions]::RemoveEmptyEntries)[-1]
        if ($ServiceStartType -imatch 'AUTO_START')
        {
            Write-Verbose -Message "$serviceName will be started Automatically."
        }
        else
        {
            Write-Error -Message "$serviceName has unexpected StartType: " + $ServiceStartType;
        }
    }

    

    # Also validate some service properties from the registry database of scm. 
    $serviceRegistryData = Get-ItemProperty hklm:\SYSTEM\CurrentControlSet\Services\$serviceName

    if($serviceRegistryData.ImagePath -eq $serviceBinaryPathCommand)
    {
        Write-Verbose -Message "$serviceName Binary is Installed Correctly."
    }
    else
    {
        write-error -Message "$serviceName binary is not Installed correctly: " + $serviceRegistryData.ImagePath;
    }    
    if($serviceRegistryData.ObjectName -eq "LocalSystem")
    {
        Write-Verbose -Message "$serviceName will run under LocalSystem Account."
    }
    else
    {
       write-error -Message "$serviceName has unexpected AccountType: " + $serviceRegistryData.ObjectName;
    }

    if ($ServiceType -eq "Dsc")
    {

        if ($serviceRegistryData.DisplayName -eq $script:DisplayName)
        {
            Write-Verbose -Message "$serviceName has correct Display Name."
        }
        else
        {
            write-error -Message "$serviceName has unexpected DisplayName:  " + $serviceRegistryData.DisplayName;
        }
        if($serviceRegistryData.Description -eq $script:Description)
        {
            Write-Verbose -Message "$serviceName has correct Description Data. "
        }
        else
        {
            write-error -Message "$serviceName has unexpected Description: " + $serviceRegistryData.Description 
        }
    }
    elseif ($ServiceType -eq "Extension")
    {
        if ($serviceRegistryData.DisplayName -eq $script:ExtDisplayName)
        {
            Write-Verbose -Message "$serviceName has correct Display Name."
        }
        else
        {
            write-error -Message "$serviceName has unexpected DisplayName:  " + $serviceRegistryData.DisplayName;
        }
        if($serviceRegistryData.Description -eq $script:ExtDescription)
        {
            Write-Verbose -Message "$serviceName has correct Description Data. "
        }
        else
        {
            write-error -Message "$serviceName has unexpected Description: " + $serviceRegistryData.Description 
        }
    }

}

<#
.Synopsis
   Get Guest Config data path.
#>
function Get-GuestConfigDataPath
{
    [CmdletBinding()]
    param ()

    return Join-Path $env:ProgramData 'GuestConfig'
}

<#
.Synopsis
   Acl Guest Config data path.
#>
function Set-GuestConfigDataPathAcl
{
    $guestConfigPath = Get-GuestConfigDataPath
    $acl = Get-Acl $guestConfigPath

    # Removing inherited access rules
    $acl.SetAccessRuleProtection($True, $False)

    # Adding new access rules for the target directory
    $BuiltinAdminSID = New-Object System.Security.Principal.SecurityIdentifier 'S-1-5-32-544' #Built-in Administrators SID
    $rule =  New-Object System.Security.AccessControl.FileSystemAccessRule($BuiltinAdminSID, 'FullControl', 'ContainerInherit, ObjectInherit', 'None', 'Allow')
    $acl.AddAccessRule($rule)
    Set-Acl $guestConfigPath $acl

    $BuiltinLocalSystemSID = New-Object System.Security.Principal.SecurityIdentifier 'S-1-5-18' #Local System SID
    $rule =  New-Object System.Security.AccessControl.FileSystemAccessRule($BuiltinLocalSystemSID, 'FullControl', 'ContainerInherit, ObjectInherit', 'None', 'Allow')
    $acl.AddAccessRule($rule)
    Set-Acl $guestConfigPath $acl
}

<#
    .SYNOPSIS
        Start the Dsc Service. Report Failure if service is not able to start. 

    .Example
       Start-DscService
#>
Function Start-DscService {
    [CmdletBinding()]
    Param(
        [Parameter()]
        [string]
        $ServiceType = "Dsc"
    )
    
    Write-Verbose -Message "In Start Dsc Service"
    if ($ServiceType -eq "Dsc")
    {
        $serviceName = $script:DscServiceName
    }
    elseif ($ServiceType -eq "Extension")
    {
        $serviceName = $script:ExtServiceName
    }
    
    
    # Start DSC Timer Service, may be retry on failure. 
    Start-Service $serviceName 

    $serviceObject = Get-Service -Name $serviceName
    
    if($serviceObject.Status -eq 'Running')
    {
        Write-Verbose -Message "$serviceName is running."
    }
    else
    {
        Write-Error "$serviceName can not be started."
    }
}

<#
    .SYNOPSIS
        Stop the Dsc service and then uninstall it.  

    .Example
       Uninstall-DscService
#>
Function Uninstall-DscService {
    [CmdletBinding()]
    Param(
        [Parameter()]
        [string]
        $ServiceType = "Dsc"
    )
    
    Write-Verbose -Message "In Uninstall-DscService"
    if ($ServiceType -eq "Dsc")
    {
        $serviceName = $script:DscServiceName
    }
    elseif ($ServiceType -eq "Extension")
    {
        $serviceName = $script:ExtServiceName
    }

    # Unregister DSC Timer Service
    
    $timeOut = [timespan]::FromMinutes(5)
    $stopRetry = [DateTime]::Now.Add($timeOut)
    $secondsBetweenRetry = 3
    Stop-Service $serviceName -ErrorAction SilentlyContinue -ErrorVariable stopTimeError
    while(((Get-Service -Name $serviceName).Status -ne 'Stopped') -and ([dateTime]::Now -le $stopRetry))
    {
          Write-Verbose "Wait for service to stop" -Verbose
          sleep -Seconds $secondsBetweenRetry
    }
    
    $serviceObject = Get-Service -Name $serviceName
    
    if($serviceObject.Status -eq 'Stopped')
    {
        Write-Verbose -Message "$serviceName is stopped."
        sc.exe delete $serviceName
    }
    else
    {
        Write-Error "$serviceName can not be Uninstalled because we are not able to stop it."
    }

    # some basic validation to check service is Uninstalled. 
    $serviceRegistryExists = Get-ItemProperty hklm:\SYSTEM\CurrentControlSet\Services\$serviceName -ErrorAction SilentlyContinue

    If ($serviceRegistryExists -ne $null) {

        # some times the registry clean up does not happen right away. Hence do retry for the check.
        while(($serviceRegistryExists -ne $null) -and ([dateTime]::Now -le $stopRetry))
        {
            sleep -Seconds $secondsBetweenRetry
            $serviceRegistryExists = Get-ItemProperty hklm:\SYSTEM\CurrentControlSet\Services\$serviceName -ErrorAction SilentlyContinue
        }

        # if service registry entry still exist.
        If ($serviceRegistryExists -ne $null)
        {
            Write-Error "$serviceName is not Uninstalled correctly. Information is Present in Registry Database."
        }
    }

    $getService = Get-Service $serviceName -ErrorAction SilentlyContinue
    
    If ($getService -ne $null) {
          Write-Error "$serviceName is not Uninstalled correctly. Service is reporting status."
    }
}

Function CheckServiceExists($serviceName)
{   
    if (Get-Service $serviceName -ErrorAction SilentlyContinue)
    {
        return $true
    }
    return $false
}

Function Restore-DscState
{
    [CmdletBinding()]
    Param()

    $srcPath = $script:MigratedDataPath
    if(-not (Test-Path $srcPath)) {
        return
    }

    # Restore Dsc State data
    $srcConfigPath = Join-Path $srcPath $script:UserConfigFolderName
    $destConfigPath = Join-Path $script:DscInstallPath $script:UserConfigFolderName
    New-Item -ItemType Directory -Path $destConfigPath -Force
    if(Test-Path $srcConfigPath) {
        Copy-Item "$srcConfigPath\\*.mof" $destConfigPath -Force
        Copy-Item "$srcConfigPath\\*.checksum" $destConfigPath -Force
    }

    # Restore Dsc Registration data
    $srcRegistrationPath = Join-Path $srcPath $script:PullServiceRegistrationInfoFolderName
    $destRegistrationPath = Join-Path $script:DscBinariesPath $script:PullServiceRegistrationInfoFolderName
    New-Item -ItemType Directory -Path $destRegistrationPath -Force
    if(Test-Path $srcRegistrationPath) {
        Copy-Item "$srcRegistrationPath\\*.*" $destRegistrationPath -Force
    }

    # Clean migration data folder.
    Remove-Item -Recurse -Force $srcPath
}

Export-ModuleMember -Function @(
    'Install-Dsc',
    'Enable-Dsc',
    'Uninstall-Dsc',
    'Update-Dsc'
    )
