$ErrorActionPreference = 'Stop'

<#
.Synopsis
    Returns payload information from glcm. This info is required to send a heart beat request to AA
#>
function Get-HeartbeatInfo
    {
    [CmdletBinding()]
    param()

    $glcm = Get-DscLocalConfigurationManager 

    $configurationName = ""
    $aaServerUrls = New-Object System.Collections.ArrayList

    if($glcm.ReportManagers)
    {
        $serverUrl = $glcm.ReportManagers.ServerURL	
        if($serverUrl -and !($aaServerUrls.Contains($serverUrl)))
        {
            $aaServerUrls.Add($serverUrl) > $null
        }
    }

    if($glcm.ResourceModuleManagers)
    {
        $serverUrl = $glcm.ResourceModuleManagers.ServerURL	
        if($serverUrl -and !($aaServerUrls.Contains($serverUrl)))
        {
            $aaServerUrls.Add($serverUrl) > $null
        }
    }

    if($glcm.ConfigurationDownloadManagers)
    {
        $serverUrl = $glcm.ConfigurationDownloadManagers.ServerURL

        try
        {
            #get configuration name if available
            if($glcm.ConfigurationDownloadManagers.CimClass -and $glcm.ConfigurationDownloadManagers.CimClass.CimClassProperties)
            {
                $configurationNamesExists = ($glcm.ConfigurationDownloadManagers.CimClass.CimClassProperties)['ConfigurationNames']
                if($configurationNamesExists)
                {
                    $configurationName = [string]($glcm.ConfigurationDownloadManagers.configurationNames)
                }
            }
        }
        catch
        { 
            Write-Verbose "[WARNING] Could not retrieve ConfigurationNames from glcm $_ ..."
        }

        if($serverUrl -and !($aaServerUrls.Contains($serverUrl)))
        {
            $aaServerUrls.Add($serverUrl) > $null
        }
    }

    $registrationMetaData = @{
        NodeConfigurationName = $configurationName
        ConfigurationMode = $glcm.ConfigurationMode
        ConfigurationModeFrequencyMins = $glcm.ConfigurationModeFrequencyMins
        RefreshFrequencyMins = $glcm.RefreshFrequencyMins
        RebootNodeIfNeeded = $glcm.RebootNodeIfNeeded
        ActionAfterReboot = $glcm.ActionAfterReboot
        AllowModuleOverwrite = $glcm.AllowModuleOverWrite
    }

    return @{
        ServerUrls = $aaServerUrls
        RegistrationMetaData = $registrationMetaData
    }
}

function Test-Command 
{
    param 
    (
        [String] $Name 
    )

    return ($null -ne (Get-Command -Name $Name -ErrorAction Continue 2> $null))
} 

function GetComputerInfoEditionId
{
    param()

    $windowsEditionId = $null

    if(Test-Command -Name Get-ComputerInfo)
    {
        $windowsEditionId = Get-ComputerInfo -Property WindowsEditionId -ErrorAction SilentlyContinue 
    }
    
    return $windowsEditionId
}

function GetEditionId
{
    param()

    $windowsEditionId = $null

    if(Test-Command -Name Get-ItemPropertyValue)
    {
        $windowsEditionId = Get-ItemPropertyValue 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion' -Name EditionId
    }
    elseif(Test-Command -Name Get-ItemProperty)
    {
        if($editionId = Get-ItemProperty -Path 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion' -Name EditionId -ErrorAction SilentlyContinue)
        {
            $windowsEditionId = $editionId.EditionID   
        }
    }
    
    return $windowsEditionId
} 

<#
.synopsis
    Returns windows edition id 
    For e.g. 
    on Nano Server returns - ServerDatacenterNano
    on Windows Client - Enterprise
#>
function Get-WindowsEdition
{
    param()

    $windowsEditionId = GetEditionId

    if(!$windowsEditionId)
    {
        if($windowsEditionId = GetComputerInfoEditionId)
        {
            $windowsEditionId = $windowsEditionId.WindowsEditionId
        }
    }
    
    return $windowsEditionId
}

<#
.Synopsis
    Returns OS major minor version
#>
function GetOSVersion {
	[CmdletBinding()]
    param()

	$majorVersion = ""
	$minorVersion = ""

	if(Test-Command -Name Get-CimInstance)
	{
		$os = Get-CimInstance Win32_OperatingSystem
	}
	else
	{
		$os = Get-WmiObject Win32_OperatingSystem
	}

	$version = $os.Version
    
    if($version)
	{
		# On PS/.NET 2.0, [System.Version] doesn't have a Parse method 
		if ($version -match '^(?<major>[0-9]+)\.(?<minor>[0-9]+)(\.[0-9]+)*$') {
			$majorVersion = [int]::Parse($matches['major'])
			$minorVersion = [int]::Parse($matches['minor'])
		}
		else
		{
			Write-Verbose "Invalid OS version: $version ..."
		}
	}

    @{
        Major  = $majorVersion
        Minor = $minorVersion
    }
}

<#
.Synopsis
    Returns VM UUID 
#>
function Get-VMUUId
{
    [CmdletBinding()]
    param() 

    $vmuuid = ""
    $status = "success"
    
    try
    {
        if(Test-Command -Name Get-CimInstance)
        {
            $computerSystemProduct = Get-CimInstance Win32_ComputerSystemProduct
        }
        else
        {
            $computerSystemProduct = Get-WmiObject Win32_ComputerSystemProduct
        }

        if($computerSystemProduct)
        {
            $vmuuid = $computerSystemProduct.UUID
        }

        Write-Verbose "VMUUId is $vmuuid ..."
    }
    catch
    {
        Write-Verbose "[WARNING] An error occurred while retrieving VM UUID $_ ..."
        
        $status = "error"
    }

    return @{
        VMUUID = $vmuuid
        Status = $status
    }
}

<#
.Synopsis
    Returns OS profile object 
#>
function Get-OSProfile
{
	[CmdletBinding()]
	param()

	$osName = Get-WindowsEdition
	$osVersion = GetOSVersion

	return @{
        Name = $osName
        Type = "Windows"
        MajorVersion = $osVersion["Major"]
        MinorVersion = $osVersion["Minor"]
        VMUUID = (Get-VMUUId).VMUUID
	}
}

function GetCimClass
{
    [CmdletBinding()]
    param(
        [String] $ClassName, 
        [String] $Namespace
    ) 

    return (Get-CimClass -ClassName MSFT_DSCMetaConfiguration -Namespace root/microsoft/windows/desiredstateconfiguration -ErrorAction Continue)
}

<#
.Synopsis
    Retrieves DSC agent id. Returns an empty string if agent id is not available
#>
function Get-DscAgentId
{
    [CmdletBinding()]
    param() 

    $agentID = ""
    $status = "success"
    
    #AgentID is not available in wmf 4.0. So return blank agent id if the property does not exists

    try
    {
        if($getlcm = GetCimClass)
        {
            if($getlcm -and $getlcm.CimClassProperties -and ($getlcm.CimClassProperties)['AgentId'])
            {
                $agentID = (Get-DscLocalConfigurationManager).AgentId
            }
        }

        Write-Verbose "AgentID is $agentID ..."
    }
    catch
    {
        Write-Verbose "[WARNING] An error occurred while retrieving agent ID $_ ..."
        
        $status = "error"
    }

    return @{
        AgentID = $agentID
        Status = $status
    }
}

<#
.Synopsis
    Returns OAAS certificate from the local machine that is used to authenticate with AA pull server
#>
function Get-OAASCertificate
{
    [CmdletBinding()]
    param(
		[Parameter(Mandatory=$true)]
		[ValidateNotNullOrEmpty()]
		[string]$ServerUrl
	)

	$subject = 'CN=' + $ServerUrl
	$certificate = Get-ChildItem Cert:\LocalMachine\My | ? Subject -eq $subject | Select-Object -First 1

	if (!$certificate) {
        throw "Failed to retrieve the OAAS certificate for heartbeat api request [ServerURL]: $ServerUrl ..."
	}

	return $certificate
}

<#
.Synopsis
    Returns OAAS endpoint
#>
function GetOAASEndpoint {
	[CmdletBinding()]
    param(
		[Parameter(Mandatory=$true)]
		[ValidateNotNullOrEmpty()]
		[string] $AgentId,

		[Parameter(Mandatory=$true)]
		[ValidateNotNullOrEmpty()]
		[string] $ServerURL
	)
	
	return ($ServerURL + "/Nodes(AgentId='" + $AgentId + "')/ExtendedProperties")
}

function SendWebRequest {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [string] $Uri,

        [Parameter(Mandatory=$true)]
        [System.Security.Cryptography.X509Certificates.X509Certificate] $Certificate,

        [Parameter(Mandatory=$true)]
        [hashtable] $Payload
	)

	$jsonPayload = ConvertTo-Json $Payload -Depth 10

	try
	{
        $response = Invoke-WebRequest `
                -Uri ([Uri] $Uri) `
                -ContentType 'application/json' `
                -Method Post `
                -Certificate $Certificate `
                -Headers @{ "protocolversion" = "2.0" } `
                -Body $jsonPayload `
                -UseBasicParsing

        return $response
	}
	finally
	{
		[System.Net.ServicePointManager]::CertificatePolicy = $null 	
	}
}

<#
.Synopsis
    Invokes AA server heartbeat endpoint to send the heartbeat request
#>
function Send-HeartbeatRequest {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [ValidateNotNullOrEmpty()]
        [string] $ServerURL, 

        [Parameter(Mandatory=$true)]
        [hashtable] $Payload
	)

	$agentId = (Get-DscAgentId)["AgentID"]
	$accountId = Split-Path -Path $ServerURL -Leaf
	$certificate = Get-OAASCertificate -ServerUrl $ServerURL
	$endpoint = GetOAASEndpoint -AgentId $agentId -ServerURL $ServerURL

    try
    {
        $response = SendWebRequest -Uri $endpoint -Certificate $certificate -Payload $Payload

        Write-Verbose "Heartbeat is sent successfully"
        return
    }
	catch
	{
		#No retries when status code is 400,401,403,404
        $message = "Invoking heartbeat web request failed for registration url {0}: {1}" -f ($ServerURL, $_.ToString().TrimEnd()) 
        Write-Verbose $message
    }
}

<#
.Synopsis
    Send Guest config heartbeat
#>
function Send-Heartbeat {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory=$true)]
        [ValidateSet('GCAgentStart')]
        [string]$Event
    )

    try
    {
        Write-Verbose "[INFO] Event $Event" -Verbose

        if((Get-module PSDesiredStateConfiguration -ListAvailable -Verbose:$false) -eq $null) {
		    Write-Verbose "[ERROR] DSC is not installed ..."  
		    Write-Verbose "[ERROR] No heartbeat sent ..."  
		    return 
        }

	    # Get dsc local configuration manager properties
	    $heartbeatInfo = Get-HeartbeatInfo
	    $serverUrls = $heartbeatInfo["ServerUrls"]

	    if(!$serverUrls)
	    {
		    Write-Verbose "[ERROR] No AA Server URLs were returned with glcm ..."  
		    Write-Verbose "[ERROR] No heartbeat sent ..."  
		    return 
	    }
        else {
            for ($i = 0; $i -lt $serverUrls.Count; $i++) {
                if(-not $serverUrls.ToLower().Contains('agentservice')) {
		            Write-Verbose "[ERROR] Node is not registered to AA Server. Server URI : $serverUrls ..."  
		            Write-Verbose "[ERROR] No heartbeat sent ..."  
		            return 
                }
            }
        } 

	    $extnInfo = @{
	        Name = "Microsoft.Powershell.DSC"
	        Version = "2.77.0.0" 
	    }

	    # Get OS Profile
	    $osProfile = Get-OSProfile

	    # Get OMS cloud if 
	    $omsCloudId = '7783-7084-3265-9085-8269-3286-77'
        
	    # Create request payload
	    $payload = @{
		    OMSCloudId = $omsCloudId
		    TimeStamp = (Get-Date -UFormat '%Y%m%d-%H%M%S')
		    VMResourceId = "" 
		    ExtensionStatusEvent = $Event
		    ExtensionInformation = $extnInfo
		    OSProfile = $osProfile
		    LCMMetaData = $heartbeatInfo["RegistrationMetaData"]
	    }
		
	    # For each server that VM is registered to, send heartbeat request to AA 
	    foreach($serverURL in $serverUrls)
	    {
		    Send-HeartbeatRequest -ServerURL $serverURL -Payload $payload 
	    }
    }
    catch 
    {
        Write-Verbose "[ERROR] occurred while sending heartbeat event: $Event ... $_"  
    }
}

Export-ModuleMember -Function @('Send-Heartbeat')