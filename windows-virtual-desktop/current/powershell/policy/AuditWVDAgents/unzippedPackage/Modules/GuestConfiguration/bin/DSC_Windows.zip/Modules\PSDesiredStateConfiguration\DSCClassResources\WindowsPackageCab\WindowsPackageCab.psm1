﻿#
# Windows Cab Package Provider - Microsoft 2016
# This resource manages the packages for a live image.
#

data LocalizedData
{
    # culture="en-US"
    ConvertFrom-StringData @'
SourcePathDoesNotExist=Source does not exist: {0}
ConfigurationStarted=The configuration of WindowsPackageCab resource is starting
ConfigurationFinished=The configuration of WindowsPackageCab resource has completed
FailedToAddPackage=Failed to add package from {0}
FailedToRemovePackage=Failed to remove package {0}
SourcePathInvalid=Source path is null or empty
'@
}

Import-LocalizedData LocalizedData -FileName WindowsPackageCab.Strings.psd1

[DscResource()]
class WindowsPackageCab {
    
    # Property: Holds the product name of the package.
    [DscProperty(Key)]
    [String] $Name;

    # Property: Makes sure a package is installed/not installed on the image.
    [DscProperty(Mandatory)]
    [ValidateSet("Absent","Present")]
    [String] $Ensure;
    
    # Property: Points to the location of a .cab file.
    [DscProperty(Mandatory)]
    [String] $SourcePath;
    
    # Property: Points the desired location for a log file
    [DscProperty()]
    [String] $LogPath;

    WindowsPackageCab()
    {
        Import-DscNativeDISMMethods
    }
    
    [void] Set()
    {
        Write-Verbose $script:LocalizedData.ConfigurationStarted

        if ([string]::IsNullOrEmpty($this.SourcePath))
        {
            Throw-TerminatingError ($script:LocalizedData.SourcePathInvalid)
        }

        $SourcePathExists = Test-Path -Path $this.SourcePath
        if (-not $SourcePathExists)
        {
            Throw-TerminatingError ($script:LocalizedData.SourcePathDoesNotExist -f $this.SourcePath)
        }
        
        if ($this.Ensure -match 'Present')
        {
            Add-CabPackage -PackagePath $this.SourcePath
        }
        else
        {
            Remove-CabPackage -PackagePath $this.SourcePath
        }

        Write-Verbose $script:LocalizedData.ConfigurationFinished
    }

    [bool] Test()
    {
        $details = Get-DISMDetailedInstalledPackageInfo -PackageName $this.Name

        $isPackagePresent = Test-PackagePresence -packageInfoDetails $details

        if ($this.Ensure -match 'Present')
        {
            return $isPackagePresent
        }
        else
        {
            return -not $isPackagePresent
        }
    }

    [WindowsPackageCab] Get()
    {
        $details = Get-DISMDetailedInstalledPackageInfo -PackageName $this.Name

        if ($details -eq $null)
        {
            $this.Ensure = 'Absent'
        }
        else
        {
            $this.Ensure = 'Present'
        }

        $this.SourcePath = $null
        $this.LogPath = $null

        return $this
    }
}

Function Trace-Message
{
    param
    (
        [string] $Message
    )

    Write-Verbose $Message

    if ($this.LogPath)
    {
        New-Item -Path $this.LogPath -ErrorAction SilentlyContinue
        Add-Content -Path $this.LogPath -Value $message
    }
}

Function Throw-TerminatingError
{
    param
    (
        [string] $Message,
        [System.Management.Automation.ErrorRecord] $ErrorRecord,
        [string] $ExceptionType
    )
    
    $exception = new-object "System.InvalidOperationException" $Message,$ErrorRecord.Exception
    $errorRecord = New-Object System.Management.Automation.ErrorRecord $exception,"MachineStateIncorrect","InvalidOperation",$null
    throw $errorRecord
}

Function Test-PackagePresence
{
    Param 
    (
        [Microsoft.PowerShell.DesiredStateConfiguration.WindowsPackageCab.DismDetailedPackageInfo] $packageInfoDetails
    )

    if (-not $packageInfoDetails)
    {
        return $false;
    }

    if ($packageInfoDetails.PackageState -eq [Microsoft.PowerShell.DesiredStateConfiguration.WindowsPackageCab.DismPackageFeatureState]::DismStateInstalled -or
        $packageInfoDetails.PackageState -eq [Microsoft.PowerShell.DesiredStateConfiguration.WindowsPackageCab.DismPackageFeatureState]::DismStateInstallPending)
    {
        return $true;
    }

    return $false;
}

Function Get-DISMDetailedInstalledPackageInfo
{
    Param
    (
        [string] $PackageName
    )

    try
    {
        $detailedPacketInfo = [Microsoft.PowerShell.DesiredStateConfiguration.WindowsPackageCab.Dism]::new().GetDetailedPackageInfo($PackageName, $this.LogPath)
    }
    catch
    {
        $detailedPacketInfo = $null
    }

    return $detailedPacketInfo
}

Function Get-DISMDetailedCabFileInfo
{
    Param
    (
        [string] $PackagePath
    )
    
    return [Microsoft.PowerShell.DesiredStateConfiguration.WindowsPackageCab.Dism]::new().GetDetailedCabFileInfo($PackagePath, $this.LogPath)
}

Function Add-CabPackage
{
    Param
    (
        [string] $PackagePath
    )

    try
    {
        $dismStatus = [Microsoft.PowerShell.DesiredStateConfiguration.WindowsPackageCab.Dism]::new().AddPackage($PackagePath, $this.LogPath)
        if ($dismStatus -eq [Microsoft.PowerShell.DesiredStateConfiguration.WindowsPackageCab.DismStatus]::DismStatusRebootRequired)
        {
            $global:DSCMachineStatus = 1;
        }
        Trace-Message ("-CabPackage successful. PackagePath = $PackagePath")
    }
    catch [System.Exception]
    {
        Throw-TerminatingError ($script:LocalizedData.FailedToAddPackage -f $this.SourcePath)
    }

}

Function Remove-CabPackage
{
    Param
    (
        [string] $PackagePath
    )

    try
    {
        $dismStatus = [Microsoft.PowerShell.DesiredStateConfiguration.WindowsPackageCab.Dism]::new().RemovePackage($PackagePath, $this.LogPath)
        if ($dismStatus -eq [Microsoft.PowerShell.DesiredStateConfiguration.WindowsPackageCab.DismStatus]::DismStatusRebootRequired)
        {
            $global:DSCMachineStatus = 1;
        }
        Trace-Message ("Remove-CabPackage successful. PackagePath = $PackagePath")
    }
    catch [System.Exception]
    {
        Throw-TerminatingError ($script:LocalizedData.FailedToRemovePackage -f $this.SourcePath)
    }
}

Function Import-DscNativeDISMMethods
{
    if (-not ([System.Management.Automation.PSTypeName]'Microsoft.PowerShell.DesiredStateConfiguration.WindowsPackageCab.Dism').Type)
    {
        $source = Get-Content "$PSScriptRoot\WindowsPackageCab.cs" -Raw
        Add-Type -TypeDefinition $source
    }
}

Export-ModuleMember -Function ''